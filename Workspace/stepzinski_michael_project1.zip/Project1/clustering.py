import math
import numpy as np
from scipy import spatial
from random import randint

def K_Means(X,K,mu):
    #print(X)
    #print(K)
    #print(mu)
    empty = ''